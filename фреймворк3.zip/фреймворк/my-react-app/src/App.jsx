import { useState, useEffect, useRef } from 'react'
const Stars = ({ rating }) => {
  const full = Math.floor(rating)             
  const hasHalf = rating - full >= 0.5          
  const empty = 5 - full - (hasHalf ? 1 : 0)   

  const stars = []                            

  //полные звез
  for (let i = 0; i < full; i++) {
    stars.push(<span key={'full' + i} className="fa fa-star active"></span>)
  }

  // полу звезд
  if (hasHalf) {
    stars.push(<span key="half" className="fa fa-star-half-o active"></span>)
  }

  //пуст звезд
  for (let i = 0; i < empty; i++) {
    stars.push(<span key={'empty' + i} className="fa fa-star"></span>)
  }

  return <div>{stars}</div>                      
}


function App() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [removingId, setRemovingId] = useState(null)
  const footer = useRef(null)

  useEffect(() => {
    fetch('https://dummyjson.com/products?limit=12')
      .then(res => res.json())
      .then(data => {
        setProducts(data.products)
        setLoading(false)
      })
  }, [])

  const goDown = () => {
    footer.current.scrollIntoView({ behavior: 'smooth' })
  }

  const deleteItem = (id) => {
    setRemovingId(id)
    setTimeout(() => {
      setProducts(prev => prev.filter(p => p.id !== id))
      setRemovingId(null)
    }, 400)
  }

  return (
    <>
      <header>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1>hed</h1>
          <button onClick={goDown}>Вниз</button>
        </div>
      </header>

      <main>
        {loading ? (
          <p style={{ textAlign: 'center', fontSize: '2rem' }}>Загрузка...</p>
        ) : (
          <div className="grid">
            {products.map(p => (
              <div
                key={p.id}
                className={`card ${removingId === p.id ? 'removing' : ''}`}
                onDoubleClick={() => deleteItem(p.id)}
              >
                <img src={p.thumbnail} alt={p.title} />
                <div>
                  <h3>{p.title}</h3>
                  <p className="price">${p.price}</p>
                  <Stars rating={p.rating} />
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <footer ref={footer}>
        <p>footer</p>
    
      </footer>
    </>
  )
}

export default App