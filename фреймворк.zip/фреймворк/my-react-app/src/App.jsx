import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [items, setItems] = useState([
    { id: 1, name: 'Велосипед', price: 1000, count: 1 },
    { id: 2, name: 'Самокат', price: 700, count: 1 },
    { id: 3, name: 'Ролики', price: 1300, count: 2 },
    { id: 4, name: 'Сноуборд', price: 19000, count: 4 },
  ]);

  const addItem = () => {
    const name = prompt("наз товара");
    const price = prompt("цена");
    const count = prompt("количество");
    if (name && price && count) {
      setItems([...items, { id: items.length + 1, name, price, count: Number(count) }]);
    }
  };

  const decreaseCount = (id) => {
    const newItems = items.map(item => {
      if (item.id === id) {
        let newCount = item.count;
        if (newCount > 0) newCount--;
        if (newCount > 25) newCount = 25;
        return { ...item, count: newCount };
      }
      return item;
    });
    const filteredItems = newItems.filter(item => item.count > 0);
    setItems(filteredItems);
  };

  const increaseCount = (id) => {
    const newItems = items.map(item => {
      if (item.id === id) {
        let newCount = item.count;
        if (newCount < 25) newCount++;
        if (newCount < 1) newCount = 1;
        return { ...item, count: newCount };
      }
      return item;
    });
    setItems(newItems);
  };

  const removeItem = (id) => {
    const newItems = items.filter(item => item.id !== id);
    setItems(newItems);
  };

  return (
    <div className="app">
      <h2>товары</h2> 
      <button onClick={addItem}>добавить</button>
      {items.map(item => (
        <div key={item.id} onDoubleClick={() => removeItem(item.id)} className="item">
          <h3>{item.name} </h3>
          <p>цена {item.price}</p>
          <button onClick={() => decreaseCount(item.id)}>-</button> 
          <span>{item.count}</span>
          <button onClick={() => increaseCount(item.id)}>+</button> 
        </div>
      ))}
    </div>
  );
};

export default App;